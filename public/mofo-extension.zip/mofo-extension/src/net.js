/* MOFO: passive capture of the JSON that fomo.family already fetches.
   Runs at document_start in the page world so it wraps fetch/XHR before the app loads.
   Nothing is sent anywhere: responses stay in this tab's memory, latest one per endpoint. */
(function (root) {
  'use strict';
  if (root.FCNet) return;
  const NET = (root.FCNet = { last: {}, listeners: [] });

  function key(url) {
    const u = new URL(url, location.href);
    return u.pathname;
  }

  function store(url, json) {
    let u;
    try {
      u = new URL(url, location.href);
    } catch (e) {
      return;
    }
    if (!/fomo\.family$/.test(u.hostname)) return;
    const rec = { path: u.pathname, host: u.hostname, params: Object.fromEntries(u.searchParams.entries()), json, at: Date.now() };
    NET.last[key(url)] = rec;
    for (const fn of NET.listeners) {
      try {
        fn(rec);
      } catch (e) {
        /* listener errors must never break the page */
      }
    }
  }

  const origFetch = root.fetch;
  root.fetch = async function (...args) {
    const res = await origFetch.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : args[0] && args[0].url;
      if (url && /fomo\.family/.test(new URL(url, location.href).hostname)) {
        res.clone().json().then((j) => store(url, j)).catch(() => {});
      }
    } catch (e) {
      /* ignore */
    }
    return res;
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__fcUrl = url;
    return origOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', () => {
      try {
        if (this.__fcUrl && (this.responseType === '' || this.responseType === 'text')) store(this.__fcUrl, JSON.parse(this.responseText));
      } catch (e) {
        /* not JSON */
      }
    });
    return origSend.apply(this, args);
  };

  // Latest response whose path contains `part`, optionally filtered by a predicate on the record.
  NET.get = function (part, pred) {
    let best = null;
    for (const rec of Object.values(NET.last)) {
      if (rec.path.includes(part) && (!pred || pred(rec)) && (!best || rec.at > best.at)) best = rec;
    }
    return best;
  };
  NET.on = function (fn) {
    NET.listeners.push(fn);
  };
})(window);
