/* MOFO: the 0-100 holder vote score. Weights and thresholds are fitted offline on the holder log (the MOFO
   collector + the charts you open) and pasted here. Until a fit beats its checks (risk level alone, holder count
   alone, a shuffled-holders placebo, on later tokens than it was fitted on) the score stays off: status 'collecting'.

   A fitted model looks like:
   { status: 'ready', version, fittedAt, tokens, list: MODEL, deep: MODEL }
   MODEL = { intercept, weights: { feature: [weight, mean, sd] }, bands: [[minScore, label], ...] }
   `list` scores GMGN's per-token holder-mix totals (trending rows / token info), `deep` the full holder profiles. */
(function (root) {
  'use strict';
  const M = { status: 'collecting', version: 0, fittedAt: null, tokens: 0, list: null, deep: null };

  function score(model, features) {
    if (M.status !== 'ready' || !model || !features) return null;
    let z = model.intercept || 0;
    let used = 0;
    for (const [name, [w, mean, sd]] of Object.entries(model.weights || {})) {
      const v = Number(features[name]);
      if (!Number.isFinite(v)) continue;
      z += w * ((v - mean) / (sd || 1));
      used++;
    }
    if (!used) return null;
    return Math.round(100 / (1 + Math.exp(-z)));
  }

  M.listScore = (features) => score(M.list, features);
  M.deepScore = (components) => score(M.deep, components);

  root.FCScoreModel = M;
  if (typeof module !== 'undefined' && module.exports) module.exports = M;
})(typeof window !== 'undefined' ? window : globalThis);
